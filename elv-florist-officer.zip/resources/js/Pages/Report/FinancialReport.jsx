export default function FinancialReport() {
  return (
    <div>FinancialReport</div>
  )
}
